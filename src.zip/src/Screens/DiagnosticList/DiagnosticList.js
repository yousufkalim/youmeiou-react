import React, { useState, useEffect } from "react";
import "./DiagnosticList.css";

//  Componnets
import Dropdown from "../../components/Dropdown/Dropdown";
import Heading from "../../components/Heading/Heading";
import Card from "../../components/Card/Card";
import List from "../../components/List/List";
import { NavLink } from "react-router-dom";
import SearchInput, { createFilter } from "react-search-input";
import { useDispatch, useSelector } from "react-redux";
import * as actionTypes from "../../store/actionTypes";
import CircularProgress from "@material-ui/core/CircularProgress";
import jwt_decode from "jwt-decode";
import Skeleton from "@material-ui/lab/Skeleton";
import endPoints from "../../globals/Constants";
import { withSnackbar } from "notistack";

// import { GiHamburgerMenu } from "react-icons/all";
// import { Images } from "../../assets/Assets";

const lists = [
  {
    id: "001",
    familyId: 1,
    name: "one",
    detail: "this is first element",
    description:
      "there is issue in this list there is issue in this list there is issue in this list",
  },
  {
    id: "002",
    familyId: 22,
    name: "two",
    detail: "this is second element",
    description: "Libellé court",
  },
  {
    id: "003",
    familyId: 22,
    name: "three",
    detail: "this is third element",
    description: "Libellé court",
  },
  {
    id: "004",
    familyId: 22,
    name: "four",
    detail: "this is fourth element",
    description: "Libellé court",
  },
  {
    id: "005",
    familyId: 1,
    name: "five",
    detail: "this is fifth element",
    description: "Libellé court",
  },
  {
    id: "006",
    familyId: 1,
    name: "six",
    detail: "this is six element",
    description: "Libellé court",
  },
  {
    id: "007",
    familyId: 1,
    name: "seven",
    detail: "this is seventh elementt",
    description: "Libellé court",
  },
  {
    id: "008",
    familyId: 2,
    name: "eight",
    detail: "this is eighth element",
    description: "Libellé court",
  },
  {
    id: "009",
    familyId: 1,
    name: "nine",
    detail: "Libellé court",
    description: "Libellé court",
  },
  {
    id: "010",
    familyId: 2,
    name: "ten",
    detail: "Libellé court",
    description: "Libellé court",
  },
];

// const families = [
//   {
//     familyId: "",
//     text: "Famille de diagnostics",
//   },
//   {
//     familyId: 22,
//     text: "abc",
//   },
//   {
//     familyId: 25,
//     text: "john",
//   },
//   {
//     familyId: 27,
//     text: "wick",
//   },
// ];

// const categories = [
//   {
//     catId: "",
//     text: "Catégorie",
//   },
//   {
//     catId: 14,
//     text: "test14",
//   },
//   {
//     catId: 7,
//     text: "test7",
//   },
//   {
//     catId: 12,
//     text: "test12",
//   },
//   {
//     catId: 17,
//     text: "test17",
//   },
//   {
//     catId: 15,
//     text: "test15",
//   },
//   {
//     catId: 13,
//     text: "test13",
//   },
//   {
//     catId: 16,
//     text: "test3",
//   },
//   {
//     catId: 18,
//     text: "test18",
//   },
// ];
const KEYS_TO_FILTERS = ["serialNo", "explanation", "shortExplanation", "name"];

const Diagnostic = (props) => {
  const [selectedFamily, setSelectedFamily] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [diagnostics, setDiagnostics] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [displayEmptyDiagosticMsg, setDisplayEmptyMsg] = useState(false);
  const [token, setToken] = useState("");
  const [families, setFamilies] = useState([
    {
      created_at: "",
      deleted_at: null,
      diagnostics: [],
      explaination: "",
      family_Id: "",
      name: "Famille de diagnostics",
      updated_at: "",
    },
  ]);
  const [categories, setCategories] = useState([
    {
      explaination: "",
      id: "",
      name: "Catégorie",
    },
  ]);
  const [spinner, setSpinner] = useState(true);

  // const [list, setList] = useState([]);
  const [toggle, setToggle] = useState(false);
  const groupProps = useState({
    appear: true,
    enter: false,
    exit: false,
  });
  const tokenId = useSelector((state) => state.user.token);
  const userToken = tokenId !== "" ? tokenId : "";

  // console.log(props);
  const dispatch = useDispatch();

  // console.log("userToken", userToken)
  // setToken(userToken);
  var userId;
  // debugger;
  if (userToken !== "") {
    var decToken = jwt_decode(userToken);
    userId = parseInt(decToken.Id);
  } else {
    userId = 0;
  }
  console.log(userId);
  // const state = useSelector((state) => state);
  // console.log("complete state", state);
  // console.log("token", token);

  useEffect(() => {
    // dispatch({ type: actionTypes.GET_DIAGNOSTICS, payload: {userToken:userToken, userId:userId} });
    getAllDiagnostics();
    getFamily();
    getCategory();
    // console.log("User data is =>>> ",decoded.email);
  }, [dispatch]);

  async function getAllDiagnostics() {
    // var decoded = jwt_decode(userToken);
    // const id = parseInt(decoded.Id);
    // console.log(id);
    await fetch(`${endPoints.GET_FILTER_DIAGNOSTICS}/${userId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${userToken}`,
      },
    })
      .then((res) => res.json())
      .then((result) => {
        if (result) {
          console.log(result);
          setDiagnostics(result);
          console.log("diagnostic result" + result.length);
          if (result.length === 0) {
            setDisplayEmptyMsg(true);
          }
          setSpinner(false);
          // console.log(result);
        } else {
          setSpinner(false);
          console.log("not result");
          // alert("hello")
          props.enqueueSnackbar("Un problème est survenu", {
            variant: "error",
          });
        }
      })
      .catch((error) => {
        setSpinner(false);
        console.log(error);
        // alert(error)
        props.enqueueSnackbar("Un problème est survenu", {
          variant: "error",
        });
      });
    // console.log(token);
  }

  async function getFamily() {
    // const token = sessionStorage.getItem("token");
    await fetch(`${endPoints.GET_FAMILY}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${userToken}`,
      },
    })
      .then((res) => res.json())
      .then((result) => {
        if (result) {
          const obj = {
            created_at: "",
            deleted_at: null,
            diagnostics: [],
            explaination: "",
            family_Id: "",
            name: "Famille de diagnostics",
            updated_at: "",
          };

          setFamilies([...families, ...result]);
          // console.log(result);
        } else {
          props.enqueueSnackbar(result.errorMessage, {
            variant: "error",
          });
        }
      })
      .catch((error) => {});
  }

  const sidebarToggle = (btn) => {
    setToggle(btn);
  };

  async function getCategory() {
    await fetch(endPoints.GET_CATEGORY, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${userToken}`,
      },
    })
      .then((res) => res.json())
      .then((result) => {
        if (result) {
          setCategories([...categories, ...result.diagCategoryContract]);
          // console.log(result.diagCategoryContract);
        } else {
          props.enqueueSnackbar(result.errorMessage, {
            variant: "error",
          });
        }
      });
  }

  const changeFamily = (e) => {
    if (selectedCategory !== "") {
      setSelectedCategory("");
      setSelectedFamily(e.target.value);
    } else {
      setSelectedFamily(e.target.value);
    }
  };

  const changeCategory = (e) => {
    if (selectedFamily !== "") {
      setSelectedFamily("");
      setSelectedCategory(e.target.value);
    } else {
      setSelectedCategory(e.target.value);
    }
  };

  const searchUpdated = (term) => {
    setSearchTerm(term);
  };

  const filteredEmails = diagnostics.filter(
    createFilter(searchTerm, KEYS_TO_FILTERS)
  );

  const sendData = () => {};
  // const items = useSelector((state) => state);
  // console.log("current state", items);
  // console.log("diagnostics =>>", selectedCategory);
  // console.log("result families ==> ", families);

  console.log("categories ", categories);
  return (
    <div className="diagnostic">
      {/* <div
          className="d-flex justify-content-between mx-3 py-1 screen-navbar"
          style={{ borderBottom: "1px solid rgba(1,35,64, 18%)" }}
        >
          <div className="sidebar-drawer-container d-flex">
            <div className="sidebar-drawer">
              {toggle === false && (
                // <GiHamburgerMenu size={30} onClick={() =>this.sidebarToggle(true)} className="sidebar-toggler mr-4" />
                <GiHamburgerMenu size={30} className="sidebar-toggler mr-5" />
              )}
            </div>
            <span>
              <img src={Images.logo} alt="logo" className="ml-5" />
            </span>
          </div>
          <div>
            <img src={Images.profile} alt="profile" className="profile-img" />
          </div>
        </div> */}
      <div
        className="diagnostic-wrapper"
        style={userToken ? { height: "90%" } : { height: "100%" }}
      >
        <div
          style={{ height: "10%", paddingTop: "1.4rem", maxHeight: "10rem" }}
          className="mx-3"
        >
          <Heading>Liste de diagnostics disponibles</Heading>
        </div>
        <div className="diagnostic-container">
          <div className="diagnostic-header">
            {/* <div className="diagnostic-dropdown">
              <Dropdown>
                <option>Risques signatures</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Dropdown>
            </div> */}
            <div className="diagnostic-dropdown">
              <Dropdown
                onChange={changeCategory}
                value={selectedCategory}
                disabled={selectedFamily !== "" ? true : false}
              >
                {categories.map((item, index) => (
                  <option key={index} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </Dropdown>
            </div>
            <div className="diagnostic-dropdown">
              <Dropdown
                value={selectedFamily}
                onChange={changeFamily}
                disabled={selectedCategory !== "" ? true : false}
              >
                {families.map((item, index) => (
                  <option value={item.family_Id} key={index}>
                    {item.name}
                  </option>
                ))}
              </Dropdown>
            </div>
            <div className="diagnostic-list-search">
              <SearchInput className="search-input" onChange={searchUpdated} />
            </div>
          </div>

          <div className="diagnostic-content">
            <div className="diagnostic-card">
              {displayEmptyDiagosticMsg ? (
                <Card
                  style={{
                    padding: "1rem 4rem 1rem 4rem",
                    borderRadius: "3.5rem",
                    position: "relative",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <h1 style={{ color: "var(--text_color)" }}>
                    No Remaining diagnostics or active diagnostics
                  </h1>
                  
                </Card>
              ) : (
                <Card
                  style={{
                    padding: "1rem 4rem 1rem 4rem",
                    borderRadius: "3.5rem",
                    position: "relative",
                  }}
                >
                  {spinner && (
                    <div className="spinner">
                      <CircularProgress className="circular-spinner-blue" />
                    </div>
                  )}
                  {/* {filteredEmails.map((item) => {
                    
                      selectedFamily.match(item.familyId) ?
                         
<NavLink to="/diagnostic-presentation">
                      <List>
                        <div className="diagnostic-list-id" style={{width: "10%"}}>{item.id}</div>
                        <div className="diagnostic-list-name" style={{width: "25%"}}>{item.name}</div>
                        <div className="diagnostic-list-id" style={{width: "20%"}}>{item.detail} </div>
                        <div className="diagnostic-list-id" style={{width: "40%"}}>
                          {item.description}
                        </div>
                      </List>
                    </NavLink>
                    : 
                    <NavLink to="/diagnostic-presentation">
                      <List>
                        <div className="diagnostic-list-id" style={{width: "10%"}}>{item.id}</div>
                        <div className="diagnostic-list-name" style={{width: "25%"}}>{item.name}</div>
                        <div className="diagnostic-list-id" style={{width: "20%"}}>{item.detail} </div>
                        <div className="diagnostic-list-id" style={{width: "40%"}}>
                          {item.description}
                        </div>
                      </List>
                    </NavLink>
                  })} */}

                  {filteredEmails.map((item) => {
                    if (selectedFamily !== "") {
                      if (selectedFamily.match(item.familyId)) {
                        return (
                          <NavLink
                            to={{
                              pathname:
                                props.match.url +
                                "/" +
                                decodeURIComponent(item.diagnosticId),
                              state: {
                                id: item.diagnosticId,
                                name: item.name,
                                explanation: item.explanation,
                              },
                            }}
                            // onClick={props.history.push()}
                          >
                            <List>
                              {/* <div
                              className="diagnostic-list-id"
                              style={{ width: "10%" }}
                              className="diagnostic-list-item"
                            >
                              {item.serialNo}
                            </div> */}
                              <div
                                className="diagnostic-list-name"
                                style={{ width: "25%" }}
                                className="diagnostic-list-item"
                              >
                                {item.name}
                              </div>
                              <div
                                className="diagnostic-list-id"
                                style={{ width: "20%" }}
                                className="diagnostic-list-item"
                              >
                                {item.shortExplanation}{" "}
                              </div>
                              <div
                                className="diagnostic-list-id"
                                style={{ width: "50%" }}
                                className="diagnostic-list-item"
                              >
                                {item.explanation}
                              </div>
                            </List>
                          </NavLink>
                        );
                      }
                    } else if (selectedCategory !== "") {
                      if (selectedCategory.match(item.categoryId)) {
                        return (
                          <NavLink
                            to={{
                              pathname:
                                props.match.url +
                                "/" +
                                decodeURIComponent(item.diagnosticId),
                              state: {
                                id: item.diagnosticId,
                                name: item.name,
                                explanation: item.explanation,
                                serialNo: item.serialNo,
                              },
                            }}
                            // onClick={props.history.push()}
                          >
                            <List>
                              {/* <div
                              className="diagnostic-list-id"
                              style={{ width: "10%" }}
                              className="diagnostic-list-item"
                            >
                              {item.serialNo}
                            </div> */}
                              <div
                                className="diagnostic-list-name"
                                style={{ width: "25%" }}
                                className="diagnostic-list-item"
                              >
                                {item.name}
                              </div>
                              <div
                                className="diagnostic-list-id"
                                style={{ width: "20%" }}
                                className="diagnostic-list-item"
                              >
                                {item.shortExplanation}{" "}
                              </div>
                              <div
                                className="diagnostic-list-id"
                                style={{ width: "50%" }}
                                className="diagnostic-list-item"
                              >
                                {item.explanation}
                              </div>
                            </List>
                          </NavLink>
                        );
                      }
                    } else {
                      return (
                        <NavLink
                          onClick={sendData}
                          to={{
                            pathname:
                              props.match.url +
                              "/" +
                              decodeURIComponent(item.diagnosticId),
                            state: { ...item },
                          }}
                        >
                          <List>
                            {/* <div
                            className="diagnostic-list-id"
                            style={{ width: "10%" }}
                            className="diagnostic-list-item"
                          >
                            {item.serialNo}
                          </div> */}
                            <div
                              className="diagnostic-list-name"
                              style={{ width: "25%" }}
                              className="diagnostic-list-item"
                            >
                              {item.name}
                            </div>
                            <div
                              className="diagnostic-list-id"
                              style={{ width: "20%" }}
                              className="diagnostic-list-item"
                            >
                              {item.shortExplanation}{" "}
                            </div>
                            <div
                              className="diagnostic-list-id"
                              style={{ width: "50%" }}
                              className="diagnostic-list-item"
                            >
                              {item.explanation}
                            </div>
                          </List>
                        </NavLink>
                      );
                    }
                  })}
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default withSnackbar(Diagnostic);
